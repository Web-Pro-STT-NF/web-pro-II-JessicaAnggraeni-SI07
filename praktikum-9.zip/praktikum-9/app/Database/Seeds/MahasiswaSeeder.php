<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use CodeIgniter\I18n\Time;

class MahasiswaSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'nim'               => '0110121145',
                'nama'              => 'Jessica',
                'jenis_kelamin'     => 'Perempuan',
                'tgl_lahir'         => '2003-06-15',
                'tempat_lahir'      => 'Cirebon',
                'program_study'     => 'Teknik Informatika',
                'ipk'               => '3.8',
                'created_at'        => Time::now()
            ],
            [
                'nim'               => '0110122334',
                'nama'              => 'Genevieve',
                'jenis_kelamin'     => 'Perempuan',
                'tgl_lahir'         => '2001-03-07',
                'tempat_lahir'      => 'Depok',
                'program_study'     => 'Teknik Informatika',
                'ipk'               => '3.4',
                'created_at'        => Time::now()
            ],
        ];
        $this->db->table('mahasiswa')->insertBatch($data);
    }
}