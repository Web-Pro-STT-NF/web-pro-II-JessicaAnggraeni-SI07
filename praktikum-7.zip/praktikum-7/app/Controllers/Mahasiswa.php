<?php

namespace App\Controllers;

use App\Models\MahasiswaModel;

class Mahasiswa extends BaseController
{
    public function index(){
        //objek model mahasiswa
        $this->mhs1 = new MahasiswaModel();
        $this->mhs2 = new MahasiswaModel();
        $this->mhs3 = new MahasiswaModel();

        //memberi nilai pada objek
        $this->mhs1->id = 1;
        $this->mhs1->nama = "Jessica Anggraeni";
        $this->mhs1->nim = "121145";
        $this->mhs1->gender = "P";
        $this->mhs1->tmp_lahir = "Bandung";
        $this->mhs1->tgl_lahir = "15 Juni 2003";
        $this->mhs1->ipk = 3.87;

        $this->mhs2->id = 2;
        $this->mhs2->nama = "Ilham Panca";
        $this->mhs2->nim = "121143";
        $this->mhs2->gender = "L";
        $this->mhs2->tmp_lahir = "Depok";
        $this->mhs2->tgl_lahir = "26 Maret 2002";
        $this->mhs2->ipk = 3.85;

        $this->mhs3->id = 3;
        $this->mhs3->nama = "Erick Brian";
        $this->mhs3->nim = "121144";
        $this->mhs3->gender = "L";
        $this->mhs3->tmp_lahir = "Tangerang";
        $this->mhs3->tgl_lahir = "23 Januari 2001";
        $this->mhs3->ipk = 3.80;

        $list_mhs = [$this->mhs1, $this->mhs2, $this->mhs3];
        $data['list_mhs'] = $list_mhs;

        //return view dan mengirim sebuah data array
        return view('mahasiswa/index', $data);
    }
}